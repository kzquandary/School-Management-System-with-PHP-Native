<div class="nav-header">
    <a href="index.php" class="brand-logo">
        <img src="images/unjani.png" alt="" width="80">
    </a>

    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>