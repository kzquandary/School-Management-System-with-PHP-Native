--- E-School by @Kzquandary ---
1. Ikuti Saya
Facebook : fb.me/Kzquandary
Instagram : @Kzquandary
2. Data Login
Kode Login : Untuk Mahasiswa menggunakan NIM, Untuk Dosen menggunakan Kode Dosen dan untuk Admin Menggunakan Kode Admin
Status dalam Database Login : 1 [ Mahasiswa ], 2 [ Dosen ], 3 [ Admin ]